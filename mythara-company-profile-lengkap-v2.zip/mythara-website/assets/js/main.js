document.addEventListener('DOMContentLoaded', () => {
  // 1. Navigasi Responsif (Mobile Menu)
  const menuToggle = document.getElementById('menuToggle');
  const navLinks = document.getElementById('navLinks');

  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });
  }

  // 2. Filter Katalog Gim (Halaman Home)
  const filterButtons = document.querySelectorAll('.filter-btn');
  const gameCards = document.querySelectorAll('.game-card');

  filterButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterButtons.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');

      const category = btn.getAttribute('data-filter');
      gameCards.forEach((card) => {
        const cardCategory = card.getAttribute('data-category');
        if (category === 'all' || cardCategory === category) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // 3. Modal Klaim Promo (Halaman Home)
  const promoModal = document.getElementById('promoModal');
  const closePromoModal = document.getElementById('closePromoModal');
  const claimButtons = document.querySelectorAll('.claim-btn');
  const copyCodeBtn = document.getElementById('copyCodeBtn');

  claimButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const title = btn.getAttribute('data-title');
      const code = btn.getAttribute('data-code');
      const price = btn.getAttribute('data-price');
      const img = btn.getAttribute('data-img');
      const desc = btn.getAttribute('data-desc');

      document.getElementById('modalGameTitle').textContent = title;
      document.getElementById('modalPromoCode').textContent = code;
      document.getElementById('modalGamePrice').textContent = price;
      document.getElementById('modalGameImg').src = img;
      document.getElementById('modalGameDesc').textContent = desc;

      if (copyCodeBtn) {
        copyCodeBtn.textContent = 'Salin Kode';
      }

      if (promoModal) {
        promoModal.classList.add('show');
      }
    });
  });

  if (closePromoModal && promoModal) {
    closePromoModal.addEventListener('click', () => {
      promoModal.classList.remove('show');
    });
    promoModal.addEventListener('click', (e) => {
      if (e.target === promoModal) {
        promoModal.classList.remove('show');
      }
    });
  }

  if (copyCodeBtn) {
    copyCodeBtn.addEventListener('click', () => {
      const codeText = document.getElementById('modalPromoCode').textContent;
      navigator.clipboard.writeText(codeText).then(() => {
        copyCodeBtn.textContent = 'Tersalin!';
      });
    });
  }

  // 4. Modal Profil Pendiri (Halaman About Us)
  const founderModal = document.getElementById('founderModal');
  const closeFounderModal = document.getElementById('closeFounderModal');
  const founderButtons = document.querySelectorAll('.founder-btn');

  founderButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      document.getElementById('modalFounderName').textContent = btn.getAttribute('data-name');
      document.getElementById('modalFounderRole').textContent = btn.getAttribute('data-role');
      document.getElementById('modalFounderBio').textContent = btn.getAttribute('data-bio');

      if (founderModal) {
        founderModal.classList.add('show');
      }
    });
  });

  if (closeFounderModal && founderModal) {
    closeFounderModal.addEventListener('click', () => {
      founderModal.classList.remove('show');
    });
    founderModal.addEventListener('click', (e) => {
      if (e.target === founderModal) {
        founderModal.classList.remove('show');
      }
    });
  }

  // 5. Formulir Kontak (Halaman About Us)
  const contactForm = document.getElementById('contactForm');
  const formFeedback = document.getElementById('formFeedback');

  if (contactForm && formFeedback) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('senderName').value.trim();
      formFeedback.textContent = `Terima kasih, ${name}! Pesan Anda telah terkirim ke tim MYTHARA.`;
      contactForm.reset();
    });
  }
});
